#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.SecretsManager';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.IdentityManagement';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.CloudWatch';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.Lambda'; ModuleVersion='4.1.240'}

function rotate-accesskeys { 
      param(
        [Parameter(Mandatory = $false)]
        [String[]]$username_exceptions ,
        [Parameter(Mandatory = $true)]
        [string]$days,
        [Parameter(Mandatory = $true)]
        [string]$region,
        [Parameter(Mandatory = $true)]
        [string]$sns_function 
    )

Set-DefaultAWSRegion -Region $region

$days_to_rotate = (Get-Date).AddDays(-$days)

if ($username_exceptions){
$exceptions = $username_exceptions -split ","
$exception_list = $exceptions.trim() -join "|"
$users = (Get-IamUsers) | Where {$_.UserName -notmatch $exception_list}
}

if ((!$username_exceptions) -or ([string]::IsNullOrWhitespace($username_exceptions))){
$users = (Get-IamUsers)
}

foreach ($user in $users){ 

$user = ($user.UserName).trim()
$ErroractionPreference = 'Stop'

try {
$getactive_key = (Get-IAMAccessKey -UserName $user | Where { $_.Status -eq "Active"}) 

if ($getactive_key.count -eq 0) { 
 continue
}

if ($getactive_key.count -eq 1) { 
 $get_key = ($getactive_key | Select -First 1).AccessKeyId
 $creation_date = ($getactive_key | Select -First 1).CreateDate
}

if ($getactive_key.count -eq 2) { 
 $get_key = ($getactive_key | Sort-Object -Property CreateDate | Select -First 1).AccessKeyId
 $creation_date = ($getactive_key | Sort-Object -Property CreateDate | Select -First 1).CreateDate
}
}catch{
 write-host "no active key was found for user $user, skipping $user since no accesskey or only existing key(s) are inactive"
}

if (($creation_date -le $days_to_rotate)) {

$access_key_id = ($get_key).trim()

try { 
#normally we want the new key before deactivating, but '&&' is upon success so this is okay
Update-IAMAccessKey -UserName $user -AccessKeyId $access_key_id -Status Inactive -Force &&
New-IAMAccessKey -UserName $user -Force | Tee-Object -Variable var_username
}
catch{
    #something is off, maybe someone had 2 active keys and/or manually deactivated an accesskey recently. 
    Remove-IAMAccessKey -AccessKeyId $access_key_id -UserName $user -Force && 
    write-host "too many keys exist for $user , removed previous active key" &&
    New-IAMAccessKey -UserName $user -Force | Tee-Object -Variable var_username   
}

$keyValuePairs = @{
"AccessKeyId" = $var_username.AccessKeyId
"SecretAccessKey" = $var_username.SecretAccessKey
}

$secret_name = $user+'_credentials'

Try{
Update-SECSecret -SecretId $secret_name -SecretString (ConvertTo-Json -InputObject $keyValuePairs)
}
catch{
$message = ($Error[0].Exception.Message)
if ($message -match "You can't perform this operation on the secret because it was marked for deletion."){ 
Restore-SECSecret -SecretId $secret_name -Force &&
Start-Sleep 1 &&
Update-SECSecret -SecretId $secret_name -SecretString (ConvertTo-Json -InputObject $keyValuePairs) -Force
}
else{
write-host "Secret did not exist for user $user, new secret created" &&
New-SECSecret -Name $secret_name -SecretString (ConvertTo-Json -InputObject $keyValuePairs)
}
}

 $policyarn = (Get-IAMUser -UserName $user).Arn

 
$sec_policy = @"
 {
   "Version": "2012-10-17",
   "Statement": [
     {
       "Effect": "Allow",
       "Principal": {
         "AWS": "$policyarn"
       },
       "Action": [
         "secretsmanager:GetSecretValue",
         "secretsmanager:DescribeSecret"
       ],
       "Resource": "*"
     }
   ]
 }
"@
 
 Write-SECResourcePolicy -ResourcePolicy $sec_policy -SecretId $secret_name &&
 write-host "SEC resource policy written/updated.."
  }
  elseif (([string]::IsNullOrWhitespace($creation_date)) -or ([string]::IsNullOrWhitespace($creation_date))){
    write-host "$user has no accesskeys or they are all Inactive"
  }
  else {
    write-host "$user keys are still valid and were created on $creation_date"
  }
 }

  Invoke-LMFunction -FunctionName $sns_function -Region $region
}

rotate-accesskeys -region $ENV:region -days $ENV:days -username_exceptions $ENV:username_exceptions -sns_function $ENV:sns_function 
