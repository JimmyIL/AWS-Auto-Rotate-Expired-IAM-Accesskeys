
#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.SecretsManager';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.CloudWatch';ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.SimpleNotificationService'; ModuleVersion='4.1.240'}
#Requires -Modules @{ModuleName='AWS.Tools.Lambda'; ModuleVersion='4.1.240'}


function publish_snstopic { 
      param(
        [Parameter(Mandatory = $true)]
        [string]$region,
        [Parameter(Mandatory = $true)]
        [string]$sns_arn 
    )

Start-Sleep 4

Set-DefaultAWSRegion -Region $region
 
$secrets = Get-SECSecretList
$a_list = @()
foreach ($secret in $secrets) { 
  $changed_recently = $secret | Where { $_.LastChangedDate -ge (Get-Date).AddDays(0)}
  $sec_name = ($changed_recently).Name   
  $a_list += $sec_name
}

if (([string]::IsNullOrWhitespace($a_list)) -or ($null -eq $a_list)){
    write-host "no accesskeys for users were changed today"
}
else{ 
$a_list = $a_list -split "_credentials", " , " 

$rotated_message = @"
Per credential rotation policy some AWS IAM users had their AccessKeys rotated.
--------------------------------------------------------------------------------------------
The New IAM User AccessKeys are in AWS SecretsManager named as ' <iamusername>_credentials '
--------------------------------------------------------------------------------------------
IAM users that had AccessKeys rotated are:
-------------------------------------------------
$a_list
"@
Publish-SNSMessage -Region $region -TopicArn $sns_arn -Message $rotated_message
}
} 

publish_snstopic -sns_arn $ENV:sns_arn -region $ENV:region
