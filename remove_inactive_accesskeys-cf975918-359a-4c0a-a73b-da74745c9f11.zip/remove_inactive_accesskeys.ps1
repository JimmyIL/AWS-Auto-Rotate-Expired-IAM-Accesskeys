# PowerShell script file to be executed as a AWS Lambda function. 
# When executing in Lambda the following variables will be predefined.
#   $LambdaInput - A PSObject that contains the Lambda function input data.
#   $LambdaContext - An Amazon.Lambda.Core.ILambdaContext object that contains information about the currently running Lambda environment.
# The last item in the PowerShell pipeline will be returned as the result of the Lambda function.
# To include PowerShell modules with your Lambda function, like the AWS.Tools.S3 module, add a "#Requires" statement
# indicating the module and version. If using an AWS.Tools.* module the AWS.Tools.Common module is also required.
#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.1.286.0'}
#Requires -Modules @{ModuleName='AWS.Tools.SecretsManager';ModuleVersion='4.1.286.0'}
#Requires -Modules @{ModuleName='AWS.Tools.IdentityManagement';ModuleVersion='4.1.286.0'}
#Requires -Modules @{ModuleName='AWS.Tools.SimpleNotificationService'; ModuleVersion='4.1.286.0'}
#Requires -Modules @{ModuleName='AWS.Tools.Lambda'; ModuleVersion='4.1.286.0'}
#Requires -Modules @{ModuleName='AWS.Tools.CloudWatchLogs';ModuleVersion='4.1.286.0'}
#Requires -Modules @{ModuleName='AWS.Tools.CloudWatch';ModuleVersion='4.1.286.0'}

function check-remove-accesskeys { 

param(
        [Parameter(Mandatory = $false)]
        [String[]]$username_exceptions ,
        [Parameter(Mandatory = $true)]
        [string]$days_to_remove_inactive,
        [Parameter(Mandatory = $true)]
        [string]$region,
        [Parameter(Mandatory = $false)]
        [string]$accesskey_rotation_lambda_name
    )

if ($username_exceptions) { 
$exceptions = $username_exceptions -split ","
$exception_list = $exceptions.trim() -join "|" 
$users = (Get-IamUsers | Where {$_.UserName -notmatch $exception_list})
}

if ((!$username_exceptions) -or ([string]::IsNullOrWhitespace($username_exceptions))) { 
  $users = (Get-IamUsers)
}

Set-DefaultAWSRegion -Region $region

$days_new_key_is_active_for = (Get-Date).AddDays(-$days_to_remove_inactive)

foreach ($user in $users){ 
$user = ($user.UserName).trim()
$erroractionpreference = 'Stop'
$list_keys = (Get-IAMAccessKey -UserName $user)
$inactive_key = ($list_keys | Where { $_.Status -eq "Inactive"}).AccessKeyId
$active_create_date = ($list_keys | Where { $_.Status -eq "Active"}).CreateDate
if (($list_keys.count -ge 2) -and ($inactive_key.count -eq 1) -and ($active_create_date -le $days_new_key_is_active_for)){
Remove-IAMAccessKey -AccessKeyId $inactive_key -UserName $user -Force && 
write-host "It has been $days_to_remove_inactive days since ACTIVE accesskey has been created. Inactive accesskey for $user was removed."
 }
}
Invoke-LMFunction -FunctionName $accesskey_rotation_lambda_name -Region $region
} 

check-remove-accesskeys -region $ENV:region -accesskey_rotation_lambda_name $ENV:accesskey_rotation_lambda_name -days_to_remove_inactive $ENV:days_to_remove_inactive -username_exceptions $ENV:username_exceptions
